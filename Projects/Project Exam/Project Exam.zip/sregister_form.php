<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
<?php include('nav.php'); ?>
<!--Form-->
<div class="w3-margin row">
 <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3 w3-padding w3-round-large w3-animate-zoom" style="box-shadow:2px 2px 20px black;">
		<h1 class="modal-title w3-center"><span class="label w3-text-black"><big class="w3-text-blue">R</big>e<i class="w3-text-red">g</i><i class="w3-text-green">i</i><i class="w3-text-sand">s</i><i class="w3-text-indigo">t</i><i class="w3-text-yellow">e</i><i class="w3-text-cyan">r</i></span></h1>
  <form name="f1" class="" method="POST" action="sregistration.php">
	<div class="row">
		<div class="col-xs-12 col-sm-4 col-md-4">
			<div class="form-group">
				<input type="text" name="fname" class="form-control input-lg" value="<?php echo $_POST['fname'] ?>" readonly="">
			</div>
		</div>
		<div class="col-xs-12 col-sm-4 col-md-4">
			<div class="form-group">
				<input type="text" name="mname" placeholder="Father's Name" class="form-control input-lg" value="<?php echo $_POST['mname'] ?>" readonly="">
			</div>
		</div>
		<div class="col-xs-12 col-sm-4 col-md-4">
			<div class="form-group">
				<input type="text" name="lname" class="form-control input-lg" value="<?php echo $_POST['lname'] ?>" readonly="">
			</div>
		</div>
	</div><!--Names-->



	<div class="row">
		<div class="col-xs-12 col-sm-6 col-md-6">
			<div class="form-group input-group">
				<span class="input-group-addon">DOB</span>
				<input type="date" class="form-control input-lg" value="<?php echo $_POST['dob'] ?>" readonly="" name="dob"></input>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-6 w3-large">
			<div class="form-group">
				<input type="text" class="form-control input-lg" name="gender" value="<?php echo $_POST['gender'] ?>" readonly="">
			</div>
		</div>
	</div><!--DOB & gender-->
	
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 w3-large">
			<div class="form-group">
				<select class="form-control input-lg" required name="course">
					<option readonly=""><?php echo $_POST['course'] ?></option>
				</select>
			</div>
		</div>
	</div><!--Course-->

    <div class="row">
		<div class="col-xs-12">
			<div class="form-group input-group">
			    <span class="input-group-addon"><img src="images\adhar.png" alt="ad" width=35 height=35></img></span>
				<input type="text" name="aadhar" class="form-control input-lg" value="<?php echo $_POST['aadhar'] ?>" readonly="">
			</div>
		</div>
	</div><!--Aadhar & address-->
      
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 w3-large">
			<div class="form-group">
				<select class="form-control input-lg" name="qual">
					<option selected readonly=""><?php echo $_POST['qual'] ?></option>
				</select>
			</div>
		</div>
		<div class="col-xs-12">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="fas fa-mobile-alt w3-xlarge"></i></span>
				<input type="text" name="mob" class="form-control input-lg" value="<?php echo $_POST['mob'] ?>" readonly="">
			</div>
		</div>
		<div class="col-xs-12">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="fas fa-envelope w3-xlarge"></i></span>
				<input type="email" name="email" class="form-control input-lg" value="<?php echo $_POST['email'] ?>" readonly="">
			</div>
		</div>
	</div><!--Mobile & Email ID-->
	
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-lock w3-xlarge"></i></span>
				<input type="password" name="pass" class="form-control input-lg" value="<?php echo $_POST['pass'] ?>" readonly="">
			</div>
		</div>
	</div><!--Password-->
	<center>
		
		<a href="register.php"><button type="button" style="width:120px;" class="w3-btn w3-btn-block w3-blue w3-round w3-large w3-hover-pale-blue w3-hover-text-blue w3-ripple w3-margin-bottom">Fill Again</button></a>
		<button type="Submit" name="submit" value="Sign Up" style="width:120px;margin:auto;" class="w3-btn w3-btn-block w3-blue w3-round w3-large w3-hover-pale-blue w3-hover-text-blue w3-ripple w3-margin-bottom">Sign Up</button>
	</center>

  </form>
 </div>
</div>

<!---------------Form End------------->


<center><h2>Already Have an Account <a href="home.html" class="w3-text-green">Login</a></h2></center>
<?php include('footer.php'); ?>
</body>
</html>