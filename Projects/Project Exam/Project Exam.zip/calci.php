<?php
session_start();
$host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$e=$_SESSION['cand'];
$conn=mysqli_connect($host, $user, $pass,$dbname);
//Session User
if(!isset($_SESSION['cand']))
{
	header('Location: logout.html');
}
else
{
unset($_SESSION['exam']);
$sql="SELECT * FROM $_SESSION[course]";
$result=mysqli_query($conn,$sql);	
if(mysqli_num_rows($result)>0)
	{
	$r=0;$w=0;$total=0;$i=1;
	while($row=mysqli_fetch_assoc($result))
		{
		$a="a".$row['qid'];
		$sql1="INSERT INTO anssubmit(qid,cans,cid,gans)
		VALUES('$row[qid]','$row[cans]','$_SESSION[cand]','$_POST[$a]')";
		mysqli_query($conn,$sql1);
		if($_POST["$a"]==$row["cans"])
		{$r++;}
		else{$w++;}
		$total++;
		if($i>10)
		{break;}
		}
	}
$p=$r/$total*100;
$sql5="SELECT * FROM studentinfo WHERE email='$e'";
$result5=mysqli_query($conn,$sql5);
$row5=mysqli_fetch_array($result5);
$sql2="INSERT INTO result(id,fname,lname,course,email,rights,wrong,total,percent)
VALUES('','$row5[fname]','$row5[lname]','$_SESSION[course]','$e','$r','$w','$total','$p')";
if(mysqli_query($conn,$sql2))
{echo "done";}
else{echo mysqli_error($conn);}
header("location:result.php");

}


?>