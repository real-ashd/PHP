<?php
echo '<img class="background: #ffffff url("./images/background.jpg") no-repeat right top;background-attachment: fixed;" src="images\banner.jpg" width="100%" height="200" style="opacity:0.9;"/>';
?>