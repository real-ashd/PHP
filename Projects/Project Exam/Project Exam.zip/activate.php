<?php 
session_start();
$host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$conn=mysqli_connect($host, $user, $pass,$dbname);
$id=$_GET['a'];
//UPDATE DATA
$sql="UPDATE studentinfo SET status='yes' WHERE id=$id";
if (mysqli_query($conn, $sql)) {
	header('Location: admin.php');
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . mysqli_error($conn);
}
if(!isset($_SESSION['luser']))
{
	header('Location: logout.html');
}
/*else
{
    $now = time();
	// checking the time now when home page starts
	if($now > $_SESSION['expire'])
		{
        session_destroy();
        echo "<p align='center'>Your session has expire ! <a href='login.php'>Login Here</a></p>";
		}
 */
    else
		{
		//starting this else one [else1]
	 // }
 
}
 
?>