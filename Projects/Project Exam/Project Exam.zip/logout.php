<?php
    session_start();
    session_destroy();
	echo '<script language="javascript">';
	echo 'alert("You Have been Logged Out")';
	echo '</script>';
?>
<!DOCTYPE html>
<html>
<body>
</body>
</html>
<?php
header('location:login.php');
?>