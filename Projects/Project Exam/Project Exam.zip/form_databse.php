<?php
$host="localhost";
$user="root";
$pass="";
$dbname="sregister";
//Connecting DATABASE
$conn=mysqli_connect($host, $user, $pass, $dbname);
if(!$conn)
  {
   echo "Connection Failed!!!!<br/>";
  }
else
  {
   echo " ";
  }
//Create Table
$sql1="CREATE TABLE studentinfo(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
fname VARCHAR(30) NOT NULL,
mname VARCHAR(30),
lname VARCHAR(30) NOT NULL,
image LONGBLOB,
dob DATE,
gender VARCHAR(30) NOT NULL,
course VARCHAR(30) NOT NULL,
aadhar BIGINT(12) NOT NULL,
qualification VARCHAR(100) NOT NULL,
mobile BIGINT(10) NOT NULL,
email VARCHAR(40) NOT NULL,
password VARCHAR(12) NOT NULL,
Time TIMESTAMP,
status VARCHAR(3)
)";
//Check if table Created or not
if(mysqli_query($conn,$sql1))
	{echo " ";}
?>