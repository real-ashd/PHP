<?php 
session_start();
$host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$e=$_SESSION['cand'];
$conn=mysqli_connect($host, $user, $pass,$dbname);
//Session User
if(!isset($_SESSION['cand']))
{
	header('Location: logout.html');
}
else
	{
unset($_SESSION['exam']);		
unset($_SESSION['pexam']);		

?>
<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
</head>
<body>

<img class="w3-card-2 w3-margin-bottom" src="images\banner.jpg" width="100%" height="200" style="opacity:0.9;"/>
<?php
$sql="SELECT id,fname,mname,lname,dob,gender,course,aadhar,qualification,mobile,email,password,Time FROM studentinfo WHERE email='$e'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
	//output data of row
	while($row=mysqli_fetch_assoc($result))
	{
		$course=$row['course'];
		GLOBAL $course;
		$_SESSION['course']=$course;
?>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="student_login.php"><span class="w3-left w3-xlarge">Welcome <?php echo $row['fname']." ".$row['lname']."."; ?></span></a>
    </div>
	<ul class="nav navbar-nav">
		<li><a href="student_login.php"><i class="fas fa-home w3-large"></i> Home</a></li>
	</ul>
	<ul class="nav navbar-nav navbar-right">
      <li><a href="#sdetail" class="w3-btn w3-green w3-hover-text-green w3-round w3-hover-white w3-margin-right w3-xlarge" data-toggle="collapse" >Profile</a></li>
      <li><a href="result.php" class="w3-btn w3-teal w3-round w3-hover-white w3-hover-text-teal w3-margin-right w3-xlarge">Result</a></li>
      <li><a href="logout.php" class="w3-btn w3-red w3-round w3-hover-white w3-hover-text-red w3-margin-right w3-xlarge">Logout</a></li>
    </ul>
</nav>

<div class="container w3-responsive w3-margin-bottom collapse" id="sdetail">
 <table class="w3-table-all text-center w3-stripped w3-card-4 table-bordered w3-hoverable w3-margin-bottom">
      <tr class="w3-sand">
        <th>Full Name</th>
        <td><?php echo $row['fname']." ".$row['mname']." ".$row['lname']."."; ?>
      </tr>
      <tr class="w3-sand">
        <th>Date of birth</th>
        <td><?php echo $row['dob']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Gender</th>
        <td><?php echo $row['gender']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Course for Examination</th>
        <td><?php echo $row['course']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Aadhar Number</th>
        <td><?php echo $row['aadhar']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Qualification</th>
        <td><?php echo $row['qualification']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Mobile Number</th>
        <td><?php echo $row['mobile']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Email ID</th>
        <td><?php echo $row['email']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Time of Registration</th>
        <td><?php echo $row['Time']; ?>
      </tr>
  </table>
</div>
<?php
	}
}
?>
<?php
$sql="SELECT * FROM result WHERE email='$e'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "<h1 class='container w3-card-2 w3-pale-red w3-padding-32' style='width:50%;'><center>Right Answers : ".$row['rights']."<br>";
echo "Wrong Answers : ".$row['wrong']."<br>";
echo "Total Questions : ".$row['total']."<br><br>";
echo "Percentage Obtained : ".$row['percent']."%<br><br>";
if($row['percent']>='70')
{
	echo "<b class='text-center'>Result : <i class='w3-text-green'>Pass</i></b><br><br>
	<a class='btn btn-warning w3-xlarge' style='width:50%;' href='certificate.php' target='_blank'>Certificate</a></center></h1>
	";
}
else {echo "<b class='text-center'>Result : <i class='w3-text-red'>Fail</i></b><center></h1>";}
?>
<?php include('footer.php'); ?>
</body>
</html>
<?php
 
}
?>