<?php
$host="localhost";
$user="root";
$pass="";
$dbname="sregister";
//Connecting DATABASE
$conn=mysqli_connect($host, $user, $pass, $dbname);
if(!$conn)
  {
   echo "Connection Failed!!!!<br/>";
  }
else
  {
   echo " ";
  }
//Create Table
$sql1="CREATE TABLE results(
id INT(6),
fname VARCHAR(30) NOT NULL,
lname VARCHAR(30) NOT NULL,
course VARCHAR(30) NOT NULL,
email VARCHAR(40) NOT NULL,
rights INT(6) NOT NULL,
wrong INT(6) NOT NULL,
marks INT(6) NOT NULL,
percent INT(6)
)";
//Check if table Created or not
if(mysqli_query($conn,$sql1))
	{echo " ";}
else{echo'failed'.mysqli_error($conn);}
?>