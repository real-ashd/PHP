<?php
session_start();
//Admin Login
if(isset($_POST['adlogin']))
{
	$u = $_POST['ad_userid'];
	$p = $_POST['ad_pass'];
	if($u=="admin" && $p=="123")
		{
		$_SESSION['luser'] = $u;
		$_SESSION['start'] = time();
		// taking now logged in time
		$_SESSION['expire'] = $_SESSION['start'] + (5 * 60) ; 
		// ending a session in 5  minutes from the starting time
		header('Location: admin.php');
	}
	else
	{
		$err= "<font color='red'>*Invalid Username or Password</font>"; 
	}
}
//Candidate Login
if(isset($_POST['calogin']))
{
	$cu=$_POST['can_userid'];
	$cp=$_POST['can_pass'];
	$host="localhost";
	$user="root";
	$pass="";
	//Connect to database Ashu
	$dbname="sregister";
	$conn=mysqli_connect($host, $user, $pass,$dbname);
	$sql="SELECT email,password,status FROM studentinfo";
	$result=mysqli_query($conn,$sql);
	while($row=mysqli_fetch_array($result))
	{
		
		if($cu == $row['email'] && $cp == $row['password'])
			{
				if($row['status']=='yes')
				{
				$id=$row['id'];
				$_SESSION['cand']=$row['email'];
				header('Location: student_login.php');
				}
				else
				{
					$a="<b class='w3-text-red'>*You are not Authorised!!! Wait for the Admin to Grant you access</b>";
				}
			}
		else
		{
			echo "<script>alert('Wrong Id or Password!!!');</script>";
		}	
	}
	
}
//Teacher Login
if(isset($_POST['telogin']))
{
	$tu=$_POST['t_userid'];
	$tp=$_POST['t_pass'];
	$host="localhost";
	$user="root";
	$pass="";
	//Connect to database Ashu
	$dbname="sregister";
	$conn=mysqli_connect($host, $user, $pass,$dbname);
	$sql="SELECT email,password,status FROM teacherinfo";
	$result=mysqli_query($conn,$sql);
	while($row=mysqli_fetch_array($result))
	{
		
		if($tu == $row['email'] && $tp == $row['password'])
			{
				if($row['status']=='yes')
				{
				$id=$row['id'];
				$_SESSION['teach']=$row['email'];
				header('Location: lteacher.php');
				}
				else
				{
					$at="<b class='w3-text-red'>*You are not Authorised!!! Wait for the Admin to Grant you access</b>";
				}
			}
		else
		{
			echo "<script>alert('Wrong Id or Password!!!');</script>";
		}	
	}
	
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
 <?php include('nav.php'); ?>
<div class="row w3-margin">
<div class="container col-sm-4 col-md-4 w3-round-large w3-animate-left w3-padding w3-card-4">
<h1 class="w3-center text-info">Admin Login</h1>
<div class="container-fluid">
	<form name="admin_login" method="post">
		<div class="form-group input-group">
			<span class="input-group-addon w3-white"><i class="glyphicon glyphicon-user w3-large"></i></span>
			<input type="text" class="form-control" placeholder="Username" name="ad_userid" required title="Enter email id">
		</div>
		<?php echo @$err; ?>
		<div class="form-group input-group">
			<span class="input-group-addon w3-white"><i class="glyphicon glyphicon-lock w3-large"></i></span>
			<input type="password" class="form-control" name="ad_pass" placeholder="Enter Password" required title="Enter your Password"><br />
		</div>
		<button type="submit" name="adlogin" class="btn btn-info">Admin Login</button>
	</form> 
</div>
</div>
<div class="container col-sm-4 col-md-4 w3-round-large w3-animate-top w3-padding w3-card-4">
<h1 class="w3-center text-danger">Teacher's Login</h1>
<div class="container-fluid">
	<form name="teacher_login" method="post">
		<div class="form-group input-group">
			<span class="input-group-addon w3-white"><i class="glyphicon glyphicon-user w3-large"></i></span>
			<input type="text" class="form-control" placeholder="Email" name="t_userid" required title="Enter email id">
		</div>
		<?php echo @$at; ?>
		<div class="form-group input-group">
			<span class="input-group-addon w3-white"><i class="glyphicon glyphicon-lock w3-large"></i></span>
			<input type="password" class="form-control" name="t_pass" placeholder="Enter Password" required title="Enter your Password">
		</div>
		<button type="submit" name="telogin" class="btn btn-danger">Teacher's Login</button>
	</form> 
</div>
</div>
<div class="container col-sm-4 col-md-4 w3-round-large w3-animate-right w3-padding w3-card-4">
<h1 class="w3-center text-success">Candidate Login</h1>
<div class="container-fluid">
	<form action="#" name="admin_login" method="post">
		<div class="form-group input-group">
			<span class="input-group-addon w3-white"><i class="glyphicon glyphicon-user w3-large"></i></span>
			<input type="text" class="form-control" placeholder="Email ID" name="can_userid" required title="Enter user id">
		</div>
		<?php echo @$a; ?>
		<div class="form-group input-group">
			<span class="input-group-addon w3-white"><i class="glyphicon glyphicon-lock w3-large"></i></span>
			<input type="password" class="form-control" name="can_pass" placeholder="Enter Password" required title="Enter your Password">
		</div>
		<button type="submit" name="calogin" class="btn btn-success">Candidate Login</button>
	</form> 
</div>
</div>
</div>


<center><h2>New Candidate <a href="register.php" class="w3-text-green">Register here</a></h2></center>
<?php include('footer.php'); ?>
</body>
</html>