<?php 
session_start();
$host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$e=$_SESSION['cand'];
$conn=mysqli_connect($host, $user, $pass,$dbname);
//Session User
if(!isset($_SESSION['cand']))
{
	header('Location: logout.html');
}
else
	{
	$_SESSION['exam']=7*60;
	header('Refresh: '.$_SESSION['exam'].'; URL=presult.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
  <style>
.mySlides {display:none}
</style>
</head>
<body>

<img class="w3-card-2 w3-margin-bottom" src="images\banner.jpg" width="100%" height="200" style="opacity:0.9;"/>

<div class="container w3-xlarge">
	
	<section class="w3-right">
		Time left<br>
		<span class='w3-red w3-right w3-xlarge btn btn-success' id="timer"></span>
	</section>
</div>
<script>
document.getElementById('timer').innerHTML =
  7 + ": " + 00;
startTimer();

function startTimer() {
  var presentTime = document.getElementById('timer').innerHTML;
  var timeArray = presentTime.split(/[:]+/);
  var m = timeArray[0];
  var s = checkSecond((timeArray[1] - 1));
  if(s==59){m=m-1}
  //if(m<0){alert('timer completed')}
  
  document.getElementById('timer').innerHTML =
    m + ":" + s;
  setTimeout(startTimer, 1000);
}

function checkSecond(sec) {
  if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
  if (sec < 0) {sec = "59"};
  return sec;
}
</script>

<?php

$sql="SELECT * FROM practice";
$result=mysqli_query($conn,$sql);
echo '<div style="margin-top:1%;" class="container w3-content">
<h1 class="w3-xxxlarge w3-text-blue w3-center">Practice Exam on '.$_SESSION['course'].'<span class="w3-right w3-large">Total Questions : 5</span></h1>';
echo '<form class="w3-margin-left" method="post" action="presult.php">';
if(mysqli_num_rows($result)>0)
{
	$i=1;
	while($row=mysqli_fetch_assoc($result))
	{
		if($row['course']==$_SESSION['course'])
		{
		echo '<div class="container mySlides w3-card w3-animate-left w3-padding" style="width:100%;">
	<big class="w3-xxlarge">Q.'.$i.'] '.$row["question"].' ?</big><br>
    <label class="radio-inline" style="margin-left:10%;">
      <input type="radio" name="a'.$row['qid'].'" value="1">'.$row["o1"].'
    </label><br>
    <label class="radio-inline" style="margin-left:10%;">
      <input type="radio" name="a'.$row['qid'].'" value="2">'.$row["o2"].'
    </label><br>
    <label class="radio-inline" style="margin-left:10%;">
      <input type="radio" name="a'.$row['qid'].'" value="3">'.$row["o3"].'
    </label><br>
	 <label class="radio-inline" style="margin-left:10%;">
      <input type="radio" name="a'.$row['qid'].'" value="4">'.$row["o4"].'
	  </label><br><br>
	  </div>
	 ';
	  $i++;
		}
	}
}
?>

 <div class="w3-center">
  <div class="w3-section">
    <button type="button" class="w3-btn w3-grey" onclick="plusDivs(-1)">Prev</button>
    <button type="button" class="w3-btn w3-grey" onclick="plusDivs(1)">Next</button>
  </div>
</div>

<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
     dots[i].className = dots[i].className.replace(" w3-red", "");
  }
  x[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " w3-red";
}
</script>

<center><input type="submit" value="Submit" name="result" class="btn btn-success w3-xlarge" style="margin-top:5%;"></input></center>
</form>
</div>
<?php include('footer.php'); ?>
</body>
</html>
<?php
 }
 
?>