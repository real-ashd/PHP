<?php
$bg="http://kb4images.com/images/grey-wallpaper/35888812-grey-wallpaper.jpg";
echo '<style>
.parallax {
    /* The image used */
    background-image: url("");

    /* Set a specific height 
    min-height: 500px; */

    /* Create the parallax scrolling effect */
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>  
</head>
<body style="background: #ffffff url('.$bg.') no-repeat right top;background-attachment: fixed;">

<!--navbar-->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Online Examination</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a> </li>
	   <li><a href="exams.php">  <span class="glyphicon glyphicon-education"></span> Exams</a> </li>
     </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
<img class="w3-card-2" src="http://preonlineexam.com/img/2.jpg" width="100%" height="200" style="opacity:0.9;"/>
</nav>';
?>