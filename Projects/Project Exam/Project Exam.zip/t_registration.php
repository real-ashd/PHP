<?php
$host="localhost";
$user="root";
$pass="";
$dbname="sregister";
//Connecting DATABASE
$conn=mysqli_connect($host, $user, $pass, $dbname);
//Inserting Data in DATABASE
$fname=$_POST['fname'];
$mname=$_POST['mname'];
$lname=$_POST['lname'];
$dob=$_POST['dob'];
$gender=$_POST['gender'];
$certification=$_POST['certification'];
$aadhar=$_POST['aadhar'];
$qual=$_POST['qual'];
$mob=$_POST['mob'];
$email=$_POST['email'];
$pass=$_POST['pass'];
if($fname && $lname && $email && $pass && $dob && $gender && $certification && $aadhar && $qual && $mob)
{
	
	$sql1="SELECT * FROM teacherinfo";
	$result=mysqli_query($conn,$sql1);
	$row=mysqli_fetch_assoc($result);
	if(!($row['email']==$email))
	{		
		$sql2="INSERT INTO teacherinfo(id,fname,mname,lname,dob,gender,certification,aadhar,qualification,mobile,email,password,Time,status)
		VALUES('','$fname','$mname','$lname','$dob','$gender','$certification','$aadhar','$qual','$mob','$email','$pass','','no')";
		if(mysqli_query($conn,$sql2)){
		echo '<script>alert("Signed Up Successfully!!!!")</script>';
		echo 'Click here to <a href="login.php">Login</a>';
		}
		else{
			echo "<script>alert('Registration Failed!!!!')</script>";
			}
	}
	else{ echo '<script>alert("Email Already Registered!!! \n\nTry registering with Different Email.")</script>';
	echo 'Click here to <a href="register.php">Register</a>';
	header("location : login.php");}
}
mysqli_close($conn);
?>