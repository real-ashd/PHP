<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
 <style>
.parallax {
    /* The image used */
    background-image: url("");

    /* Set a specific height */
    min-height: 500px; 

    /* Create the parallax scrolling effect */
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>  
</head>
<body style="background: #ffffff url('background.jpg') no-repeat right top;background-attachment: fixed;">

<!--navbar-->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Online Examination</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="home.html"><span class="glyphicon glyphicon-home"></span> Home</a> </li>
	   <li><a href="exams.html">  <span class="glyphicon glyphicon-education"></span> Exams</a> </li>
     </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
<img class="w3-card-2" src="http://preonlineexam.com/img/2.jpg" width="100%" height="200" style="opacity:0.9;"/>
</nav>
<!--Form-->
<div class="container-fluid">
<div class="">
 <div class="col-xs-12 col-sm-6 col-md-6 w3-padding " style="box-shadow:2px 2px 20px black;">
		<h1 class="modal-title w3-center"><span class="label w3-text-black"><big class="w3-text-blue">T</big>e<i class="w3-text-red">a</i><i class="w3-text-green">c</i><i class="w3-text-sand">h</i><i class="w3-text-yellow">e</i><i class="w3-text-cyan">r</i></span></h1>
		
	<form name="f1" class="" action="register_form.php" method="POST">
	<div class="row">
		<div class="col-xs-12 col-sm-4 col-md-4">
			<div class="form-group">
				<input type="text" name="tfname" class="form-control input-lg" autocomplete autofocus required placeholder="First Name" pattern=[A-Za-z]{3,30} maxlength="30" title="Enter First Name">
			</div>
		</div>
		<div class="col-xs-12 col-sm-4 col-md-4">
			<div class="form-group">
				<input type="text" name="tmname" class="form-control input-lg" autocomplete placeholder="Middle Name (Optional)" pattern=[A-Za-z]{3,30} maxlength="30" title="Enter Middle Name">
			</div>
		</div>
		<div class="col-xs-12 col-sm-4 col-md-4">
			<div class="form-group">
				<input type="text" name="tlname" class="form-control input-lg" autocomplete required placeholder="Last Name" pattern=[A-Za-z]{3,30} maxlength="30" title="Enter Last Name">
			</div>
		</div>
	</div><!--Names-->
	<div class="row">
		<div class="col-xs-12">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="fas fa-mobile-alt w3-xlarge"></i></span>
				<input type="text" name="tmob" class="form-control input-lg" autocomplete required placeholder="Mobile Number" pattern=[0-9]{10} maxlength="10" title="Enter Mobile Number">
			</div>
		</div>
		<div class="col-xs-12">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="fas fa-envelope w3-xlarge"></i></span>
				<input type="email" name="temail" class="form-control input-lg" autocomplete required placeholder="Email address" title="Enter Email ID">
			</div>
		</div>
	</div><!--Mobile & Email ID-->
	
	<div class="row">
		<div class="col-xs-12 col-sm-6 col-md-6">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-lock w3-xlarge"></i></span>
				<input type="password" name="tpass" class="form-control input-lg" autocomplete required placeholder="Password" pattern=[A-Za-z0-9]{5,10} maxlength="10" title="Password must be 5-10 characters (No Speacial Characters!)">
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-6 w3-large">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-lock w3-xlarge"></i></span>
				<input type="password" name="tcpass" class="form-control input-lg" autocomplete required placeholder="Confirm Password" pattern=[A-Za-z0-9]{5,10} maxlength="10" title="Re-Enter Password">
			</div>
		</div><br /><?php echo @$err; ?>
	</div><!--Password-->
	<center>
		
		<button type="Reset" Value="Reset" style="width:120px;" class="w3-btn w3-btn-block w3-blue w3-round w3-large w3-hover-pale-blue w3-hover-text-blue w3-ripple w3-margin-bottom">Reset</button>
		<button type="submit" name="tsubmit" value="Sign Up" style="width:120px;margin:auto;" class="w3-btn w3-btn-block w3-blue w3-round w3-large w3-hover-pale-blue w3-hover-text-blue w3-ripple w3-margin-bottom">Verify</button>
	</center>

</form>
</div>
</div>


<!--student signup-->
<div class="">
 <div class="col-xs-12 col-sm-6 col-md-6 w3-padding" style="box-shadow:2px 2px 20px black;">
		<h1 class="modal-title w3-center"><span class="label w3-text-black"><big class="w3-text-blue">S</big>t<i class="w3-text-red">u</i><i class="w3-text-green">d</i><i class="w3-text-sand">e</i><i class="w3-text-indigo">n</i><i class="w3-text-yellow">t</i><i class="w3-text-cyan"></i></span></h1>
		
	<form name="f1" class="" action="register_form.php" method="POST">
	<div class="row">
		<div class="col-xs-12 col-sm-4 col-md-4">
			<div class="form-group">
				<input type="text" name="fname" class="form-control input-lg" autocomplete autofocus required placeholder="First Name" pattern=[A-Za-z]{3,30} maxlength="30" title="Enter First Name">
			</div>
		</div>
		<div class="col-xs-12 col-sm-4 col-md-4">
			<div class="form-group">
				<input type="text" name="mname" class="form-control input-lg" autocomplete placeholder="Father's Name (Optional)" pattern=[A-Za-z]{3,30} maxlength="30" title="Enter Father's Name">
			</div>
		</div>
		<div class="col-xs-12 col-sm-4 col-md-4">
			<div class="form-group">
				<input type="text" name="lname" class="form-control input-lg" autocomplete required placeholder="Last Name" pattern=[A-Za-z]{3,30} maxlength="30" title="Enter Last Name">
			</div>
		</div>
	</div><!--Names-->
	<div class="row">
		<div class="col-xs-12 col-sm-6 col-md-6">
			<div class="form-group input-group">
				<span class="input-group-addon">DOB</span>
				<input type="date" class="form-control input-lg" title="Date of Birth" name="dob" required></input>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-6 w3-large">
			<div class="form-group">
				<center>Gender : 
				<input type="radio" name="gender" value="male" checked> Male
				<input type="radio" name="gender" value="female"> Female<center>
			</div>
		</div>
	</div><!--DOB & gender-->
	
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 w3-large">
			<div class="form-group">
				<select class="form-control input-lg" required name="course">
					<option value="">----Select Your Course for Exam----</option>
					<option>HTML</option>
					<option>CSS</option>
					<option>JAVASCRIPT</option>
					<option>BOOTSTRAP</option>
				</select>
			</div>
		</div>
	</div><!--Course-->

    <div class="row">
		<div class="col-xs-12">
			<div class="form-group input-group">
			    <span class="input-group-addon"><img src="images\adhar.png" alt="ad" width=35 height=35></img></span>
				<input type="text" name="aadhar" class="form-control input-lg" autocomplete required placeholder="Enter AADHAR Number" pattern=[0-9]{12} maxlength="12" title="Enter Aadhar Number">
			</div>
		</div>
	</div><!--Aadhar & address-->
    
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 w3-large">
			<div class="form-group">
				<select class="form-control input-lg" name="qual" required>
					<option value="">----Select Your Qualification----</option>
					<option>SSC</option>
					<option>HSC</option>
					<option>GRADUATE</option>
					<option>POST GRADUATE</option>
				</select>
			</div>
		</div>
		<div class="col-xs-12">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="fas fa-mobile-alt w3-xlarge"></i></span>
				<input type="text" name="mob" class="form-control input-lg" autocomplete required placeholder="Mobile Number" pattern=[0-9]{10} maxlength="10" title="Enter Mobile Number">
			</div>
		</div>
		<div class="col-xs-12">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="fas fa-envelope w3-xlarge"></i></span>
				<input type="email" name="email" class="form-control input-lg" autocomplete required placeholder="Email address" title="Enter Email ID">
			</div>
		</div>
	</div><!--Mobile & Email ID-->
	
	<div class="row">
		<div class="col-xs-12 col-sm-6 col-md-6">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-lock w3-xlarge"></i></span>
				<input type="password" name="pass" class="form-control input-lg" autocomplete required placeholder="Password" pattern=[A-Za-z0-9]{5,10} maxlength="10" title="Password must be 5-10 characters (No Speacial Characters!)">
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-6 w3-large">
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-lock w3-xlarge"></i></span>
				<input type="password" name="cpass" class="form-control input-lg" autocomplete required placeholder="Confirm Password" pattern=[A-Za-z0-9]{5,10} maxlength="10" title="Re-Enter Password">
			</div>
		</div><br /><?php echo @$err; ?>
	</div><!--Password-->
	<center>
		
		<button type="Reset" Value="Reset" style="width:120px;" class="w3-btn w3-btn-block w3-blue w3-round w3-large w3-hover-pale-blue w3-hover-text-blue w3-ripple w3-margin-bottom">Reset</button>
		<button type="submit" name="submit" value="Sign Up" style="width:120px;margin:auto;" class="w3-btn w3-btn-block w3-blue w3-round w3-large w3-hover-pale-blue w3-hover-text-blue w3-ripple w3-margin-bottom">Verify</button>
	</center>

  </form>
 </div>
</div>
</div>

</form>
</div>
<center><h2>Already Have an Account <a href="login.php" class="w3-text-green">Login</a></h2></center>

</div>