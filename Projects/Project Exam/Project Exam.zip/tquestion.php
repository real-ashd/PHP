<?php
session_start();
$e=$_SESSION['teach'];
$host="localhost";
$user="root";
$pass="";
$dbname="sregister";
//Connecting DATABASE
$conn=mysqli_connect($host, $user, $pass, $dbname);
$course=$_GET['course'];
//Session User
if(!isset($_SESSION['teach']))
{
	header('Location: logout.html');
}
/*else
{
    $now = time();
	// checking the time now when home page starts
	if($now > $_SESSION['expire'])
		{
        session_destroy();
        echo "<p align='center'>Your session has expire ! <a href='login.php'>Login Here</a></p>";
		}
 */
    else
		{
		//starting this else one [else1]
//Inserting Data in DATABASE

if(isset($_POST['submit']))
{
	$corr=$_POST['corr'];
	$sql1="SELECT * FROM $course";
	$result=mysqli_query($conn,$sql1);
	$row=mysqli_fetch_assoc($result);
	if(!($row['question']==$_POST['question'] && $corr==$row['cans']))
	{		
		$question=$_POST['question'];
		$option1=$_POST['option1'];
		$option2=$_POST['option2'];
		$option3=$_POST['option3'];
		$option4=$_POST['option4'];
		
		$sql2="INSERT INTO $course(qid,question,o1,o2,o3,o4,cans,id)
		VALUES('','$question','$option1','$option2','$option3','$option4','$corr','$e')";
		if(mysqli_query($conn,$sql2))
		{
		echo '<script>alert("Question added!!!!")</script>';
		}
		else
		{
		echo '<script>alert("Failed")</script>'.mysqli_error($conn);
		}
	}
else{ echo '<script>alert("Question Already Exists!!! \n\nTry Different Question.")</script>';}
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
</head>
<body>

<img class="w3-card-2 w3-margin-bottom" src="images\banner.jpg" width="100%" height="200" style="opacity:0.9;"/>



<?php
$sql="SELECT * FROM teacherinfo WHERE email='$e'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
	//output data of row
	while($row=mysqli_fetch_assoc($result))
	{
?>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="lteacher.php"><span class="w3-left w3-xlarge">Welcome <?php echo $row['fname']." ".$row['lname']."."; ?></span></a>
    </div>
	<ul class="nav navbar-nav navbar-right">
      <li><a href="#sdetail" class="w3-btn w3-green w3-hover-text-green w3-round w3-hover-white w3-margin-right w3-xlarge" data-toggle="collapse" >Profile</a></li>
      <li><a href="logout.php" class="w3-btn w3-red w3-round w3-hover-white w3-hover-text-red w3-margin-right w3-xlarge">Logout</a></li>
    </ul>
</nav>

<div class='container'>
<a href='lteacher.php' class='btn btn-info w3-right w3-xlarge' style='width:20%'>Back</a>
</div>
<h5 class="container">Note : While adding HTML Tags in Questions use <strong>"& lt;"</strong> at the place of '&lt;' and <strong>"& gt;"</strong> at the place of '&gt;' without blank space between '&' and 'lt' or 'gt'.</h5>


<div class="container w3-responsive w3-margin-bottom collapse" id="sdetail">
 <table class="w3-table-all text-center w3-stripped w3-card-4 table-bordered w3-hoverable w3-margin-bottom">
      <tr class="w3-sand">
        <th>Full Name</th>
        <td><?php echo $row['fname']." ".$row['mname']." ".$row['lname']."."; ?>
      </tr>
      <tr class="w3-sand">
        <th>Date of birth</th>
        <td><?php echo $row['dob']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Gender</th>
        <td><?php echo $row['gender']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Certification</th>
        <td><?php echo $row['certification']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Aadhar Number</th>
        <td><?php echo $row['aadhar']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Qualification</th>
        <td><?php echo $row['qualification']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Mobile Number</th>
        <td><?php echo $row['mobile']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Email ID</th>
        <td><?php echo $row['email']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Time of Registration</th>
        <td><?php echo $row['Time']; ?>
      </tr>
  </table>
</div>

<div class="container">
<h1>Add Question.</h1>
 <form method="post" class="">
  <div class="form-group col-sm-12">
    <label for="comment">Question :</label>
    <textarea class="form-control" name="question" rows="3" autofocus></textarea>
  </div>
	<div class="form-group col-sm-3">
      <label>a]. </label>
      <input class="form-control" type="text" placeholder="Option 1" name="option1" required>
    </div>
    <div class="form-group col-sm-3">
      <label>b]. </label>
      <input class="form-control" type="text" placeholder="Option 2" name="option2" required>
    </div>
    <div class="form-group col-sm-3">
      <label>c]. </label>
      <input class="form-control" type="text" placeholder="Option 3" name="option3" required>
    </div>
    <div class="form-group col-sm-3">
      <label>d]. </label>
      <input class="form-control" type="text" placeholder="Option 4" name="option4" required>
    </div>
   <div class="form-group col-sm-12"> 
 <label>Correct Answer : </label>   
  <form>
    <label class="radio-inline">
      <input type="radio" name="corr" value="1" required>A
    </label>
    <label class="radio-inline">
      <input type="radio" name="corr" value="2">B
    </label>
    <label class="radio-inline">
      <input type="radio" name="corr" value="3">C
    </label>
	 <label class="radio-inline">
      <input type="radio" name="corr" value="4">D
    </label>
	</div>
	<center><button type="submit" name="submit" class="btn btn-warning w3-margin">Submit</button></center>
  </form>
</div> 
   
  </form>
</div>
</div>



<?php
}
}
 else
{
	echo "<h1>Not Found</h1>";
}
echo "<h1 class='w3-center w3-text-red'>Questions Added</h1>";
$sql4="SELECT * FROM $course";
$result4=mysqli_query($conn,$sql4);

if(mysqli_num_rows($result4)>0)
{
	$i=1;
	while($row4=mysqli_fetch_assoc($result4))
	{
	echo "<div class='container'>
	Q.".$i."} ".$row4['question']."?<br/>
		  (1) ".$row4['o1']."<b class='w3-right'>Correct Ans : (".$row4['cans'].")</b><br>
		  (2) ".$row4['o2']."<br>
		  (3) ".$row4['o3']."<br>
		  (4) ".$row4['o4']."</div><br>";
		$i++;
	}
}
else
{
	echo "<b>No Results Found</b>";
}
?>
<?php include('footer.php'); ?>
</body>
</html>


<?php
 
// }
 
}
 
?>