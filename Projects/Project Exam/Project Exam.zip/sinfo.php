<?php 
session_start();
$host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$conn=mysqli_connect($host, $user, $pass,$dbname);
$id=$_GET['a'];
$sql="SELECT id,fname,mname,lname,dob,gender,course,aadhar,qualification,mobile,email,password,Time,status FROM studentinfo WHERE id='$id'";
$result=mysqli_query($conn,$sql);
if(!isset($_SESSION['luser']))
{
	header('Location: logout.html');
}
/*else
{
    $now = time();
	// checking the time now when home page starts
	if($now > $_SESSION['expire'])
		{
        session_destroy();
        echo "<p align='center'>Your session has expire ! <a href='login.php'>Login Here</a></p>";
		}
 */
    else
		{
		//starting this else one [else1]

?>
<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
</head>
<body>

<img class="w3-card-2 w3-margin-bottom" src="images\banner.jpg" width="100%" height="200" style="opacity:0.9;"/>
<div class="container-fluid">
<a href="logout.php" class="w3-btn w3-right w3-margin-top w3-xlarge w3-red w3-round-large w3-hover-white">Logout</a>
<span class="w3-xlarge"><a href="admin.php"> Welcome <?php echo $_SESSION['luser']; ?></a></span>
</div>

</div>
<p>

 <?php
if(mysqli_num_rows($result)>0)
{
	//output data of row
	while($row=mysqli_fetch_assoc($result))
	{
?>
<div class="container w3-responsive">
  <h1 class="w3-text-green text-center">Student Info</h1>
  <table class="w3-table-all text-center w3-stripped w3-card-4 table-bordered w3-hoverable">
      <tr class="w3-sand">
        <th>Full Name</th>
        <td><?php echo $row['fname']." ".$row['mname']." ".$row['lname']."."; ?>
      </tr>
      <tr class="w3-sand">
        <th>Date of birth</th>
        <td><?php echo $row['dob']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Gender</th>
        <td><?php echo $row['gender']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Course for Examination</th>
        <td><?php echo $row['course']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Aadhar Number</th>
        <td><?php echo $row['aadhar']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Qualification</th>
        <td><?php echo $row['qualification']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Mobile Number</th>
        <td><?php echo $row['mobile']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Email ID</th>
        <td><?php echo $row['email']; ?>
      </tr>
	  <tr class="w3-sand">
        <th>Status</th>
        <td><?php echo $row['status']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Time of Registration</th>
        <td><?php echo $row['Time']; ?>
      </tr>
  </table>
</div>
<?php
}
}
 else
{
	echo "<h1>Not Found</h1>";
}
?>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<?php include('footer.php'); ?>
</body>
</html>
<?php
 
// }
 
}
 
?>