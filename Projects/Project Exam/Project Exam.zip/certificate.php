<?php
session_start();
$host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$e=$_SESSION['cand'];
$conn=mysqli_connect($host, $user, $pass,$dbname);
//Session User
if(!isset($_SESSION['cand']))
{
	header('Location: logout.html');
}
$sql="SELECT * FROM result WHERE email='$e'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);




/*                       PDF GENERATION               */
require('fpdf/fpdf.php');
/*$pdf = new FPDF(); 
$pdf->AddPage();
$pdf->Image('unpaid.png',0,0,32,32,'PNG'); */

class PDF extends FPDF
{
// Page header
function Header()
{
	// Logo
	
    // Arial bold 15
    $this->SetFont('Arial','B',40);
	$this->SetTextColor(192,0,0);
    // Move to the right
	$this->Cell(210,30,'',0,1,'C');
	$this->Image('images/border.jpg',10,10,190,277,'JPG');
	$this->Image('images/outline.png',5,5,200,287,'PNG');
	$this->Image('images/badge.png',150,15,40,0,'PNG');
	$this->Cell(210,20,'',0,1,'C');
	$this->SetFillColor(25, 25, 255);
	$this->Cell(210,20,'International',0,1,'C');
	$this->Cell(210,20,'Certification',0,1,'C');
    
	
	
}
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-50);
    // Arial italic 8
    $this->SetFont('Arial','B',10);
    // Page number
    $this->SetMargins(10,0,10);
	$this->SetFillColor(25, 25, 255);
	$this->Cell(210,5,'',0,1,'C');
}
}
// Instanciation of inherited class
$pdf = new PDF();
$pdf->SetMargins(10,0,0);
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','I',25);
//From
$pdf->SetDrawColor(19,29,252);
$pdf->SetFillColor(0, 128, 255);
$pdf->Cell(210,15,'This is to certify that',0,1,'C');
$pdf->Cell(210,5,'',0,1,'C');
$pdf->SetFont('Times','B',30);
$pdf->Cell(210,15,'Mr/Ms '.$row['fname'].' '.$row['lname'],0,1,'C');
$pdf->Cell(210,5,'',0,1,'C');
$pdf->SetFont('Times','I',25);
$pdf->Cell(210,15,'has completed the certification course of',0,1,'C');
$pdf->SetFont('Times','B',40);
$pdf->Cell(210,5,'',0,1,'C');
$pdf->Cell(210,15,'',0,1,'C');
$pdf->Image('images/'.$row['course'].'.png',90,150,40,30,'PNG');

$pdf->SetFont('Times','I',25);
$pdf->Cell(210,5,'',0,1,'C');
$pdf->Cell(210,15,'',0,1,'C');
$pdf->Cell(210,15,'with score of '.$row['rights'].' out of '.$row['total'],0,1,'C');
$pdf->SetFont('Times','I',25);
$pdf->Cell(210,5,'',0,1,'C');
$pdf->SetMargins(0,0,0);
$pdf->Cell(210,15,'and gained '.$row['percent'].'% Percentage in the Exam.',0,1,'C');
$pdf->SetFillColor(25, 25, 255);

$pdf->Output();
?>