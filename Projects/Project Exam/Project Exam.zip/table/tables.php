<?php
$host="localhost";
$user="root";
$pass="";
$conn=mysqli_connect($host, $user, $pass);
if(!$conn)
  {
   echo "Connection Failed!!!!<br/>";
  }
else
  {
   echo "Connection Successful<br/>";
  }

//Create DATABASE
$sql="CREATE DATABASE sregister";
mysqli_query($conn,$sql);
$dbname="sregister";
//Connecting DATABASE
$conn=mysqli_connect($host, $user, $pass, $dbname);
if(!$conn)
  {
   echo "Connection Failed!!!!<br/>";
  }
//Create Studentinfo
$sql1="CREATE TABLE studentinfo(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
fname VARCHAR(30) NOT NULL,
mname VARCHAR(30),
lname VARCHAR(30) NOT NULL,
image LONGBLOB,
dob DATE,
gender VARCHAR(30) NOT NULL,
course VARCHAR(30) NOT NULL,
aadhar BIGINT(12) NOT NULL,
qualification VARCHAR(100) NOT NULL,
mobile BIGINT(10) NOT NULL,
email VARCHAR(40) NOT NULL,
password VARCHAR(12) NOT NULL,
Time TIMESTAMP,
status VARCHAR(3)
)";
mysqli_query($conn,$sql1);

//Create Techer Info
$sql2="CREATE TABLE teacherinfo(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
fname VARCHAR(30) NOT NULL,
mname VARCHAR(30),
lname VARCHAR(30) NOT NULL,
image LONGBLOB,
dob DATE,
gender VARCHAR(30) NOT NULL,
certification VARCHAR(30) NOT NULL,
aadhar BIGINT(12) NOT NULL,
qualification VARCHAR(100) NOT NULL,
mobile BIGINT(10) NOT NULL,
email VARCHAR(40) NOT NULL,
password VARCHAR(12) NOT NULL,
Time TIMESTAMP,
status VARCHAR(3)
)";
mysqli_query($conn,$sql2);

//Create Table
$sql3="CREATE TABLE HTML(
qid INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
question VARCHAR(255) NOT NULL,
o1 VARCHAR(255),
o2 VARCHAR(255),
o3 VARCHAR(255),
o4 VARCHAR(255),
cans VARCHAR(255),
id VARCHAR(255)
)";
mysqli_query($conn,$sql3);

//Create CSS
$sql4="CREATE TABLE CSS(
qid INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
question VARCHAR(255) NOT NULL,
o1 VARCHAR(255),
o2 VARCHAR(255),
o3 VARCHAR(255),
o4 VARCHAR(255),
cans VARCHAR(255),
id VARCHAR(255)
)";
//Check if table Created or not
if(mysqli_query($conn,$sql4))
	{echo "";}


//Create Table
$sql5="CREATE TABLE PYTHON(
qid INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
question VARCHAR(255) NOT NULL,
o1 VARCHAR(255),
o2 VARCHAR(255),
o3 VARCHAR(255),
o4 VARCHAR(255),
cans VARCHAR(255),
id VARCHAR(255)
)";
//Check if table Created or not
if(mysqli_query($conn,$sql5))
	{echo "";}


//Create Table
$sql6="CREATE TABLE JAVASCRIPT(
qid INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
question VARCHAR(255) NOT NULL,
o1 VARCHAR(255),
o2 VARCHAR(255),
o3 VARCHAR(255),
o4 VARCHAR(255),
cans VARCHAR(255),
id VARCHAR(255)
)";
//Check if table Created or not
if(mysqli_query($conn,$sql6))
	{echo "";}


//Create Table
$sql8="CREATE TABLE practice(
qid INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
question VARCHAR(255) NOT NULL,
o1 VARCHAR(255),
o2 VARCHAR(255),
o3 VARCHAR(255),
o4 VARCHAR(255),
cans VARCHAR(255),
course VARCHAR(255)
)";
mysqli_query($conn,$sql8);


//Create Table
$sql7="CREATE TABLE anssubmit(
qid INT(6),
cans INT(255),
cid VARCHAR(255),
gans INT(11)
)";
mysqli_query($conn,$sql7);

//Create Table
$sql8="CREATE TABLE result(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
fname VARCHAR(255),
lname VARCHAR(255),
course VARCHAR(255),
email VARCHAR(255),
rights INT(6),
wrong INT(6),
total INT(6),
percent VARCHAR(5)
)";
//Check if table Created or not
if(mysqli_query($conn,$sql8))
	{echo "done";}
else {echo mysqli_error($conn);}
?>