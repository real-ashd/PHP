<?php
$host="localhost";
$user="root";
$pass="";
$conn=mysqli_connect($host, $user, $pass);
if(!$conn)
  {
   echo "Connection Failed!!!!<br/>";
  }
else
  {
   echo "Connection Successful<br/>";
  }

//Create DATABASE
$sql="CREATE DATABASE sregister";
mysqli_query($conn,$sql);
$dbname="sregister";
//Connecting DATABASE
$conn=mysqli_connect($host, $user, $pass, $dbname);
if(!$conn)
  {
   echo "Connection Failed!!!!<br/>";
  }
$teach="INSERT INTO teacherinfo(id,fname,mname,lname,dob,gender,certification,aadhar,qualification,mobile,email,password,Time,status)
VALUES('','teacher1','','1','01-01-2000','Male','MTA','111111111111','GRDUATE','9999999999','teacher1@gmail.com','123456','','yes')";
mysqli_query($conn,$teach);

$stud="INSERT INTO studentinfo(id,fname,mname,lname,dob,gender,course,aadhar,qualification,mobile,email,password,Time,status)
VALUES('','stud1','','1','01-01-2000','Male','HTML','111111111111','HSC','9999999999','stud1@gmail.com','123456','','yes')";
mysqli_query($conn,$stud);




//Practice Questions
$pque = "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('1','What does HTML stands for','Hyper Text Markup Language','Hyper Text Transfer Protocol','Hyper Text','Hyp','4','HTML');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('2','Which Tag belongs to html 5','&lt;head&gt; tag','&lt;p&gt; tag','&lt;h&gt; tag','&lt;span&gt; tag','4','HTML');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('3','What is the extenion for html file','.htm','.html','Both 1 & 2','None','3','HTML');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('4','Choose the correct HTML element to define emphasized text','&lt;italic&gt;','&lt;i&gt;','&lt;em&gt;','&lt;empasize&gt;','3','HTML');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('5','How can you make a numbered list','&lt;ol&gt;','&lt;dl&gt;','&lt;ul&gt;','&lt;list&gt;','1','HTML');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('6','What does CSS stands for','Colorful Style Sheets','Cascading Style Sheets','Computer Style Sheets','Comaptible Style Sheets','2','CSS');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('7','Where in an HTML document is the correct place to refer to an external style sheet','In the &lt;body&gt; section','At the end of the document','In the &lt;head&gt; section','In the &lt;title&gt; section','3','CSS');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('8','Which HTML tag is used to define an internal style sheet','&lt;style&gt;','&lt;script&gt;','&lt;css&gt;','&lt;link&gt;','1','CSS');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('9','Which HTML attribute is used to define inline styles','styles','font','class','style','4','CSS');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('10','How do you insert a comment in a CSS file','/ this is a comment /','//this is a comment','//this is a comment//','/*this is a comment*/','4','CSS');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('11','Inside which HTML element do we put the JavaScript','&lt;scripting&gt;','&lt;script&gt;','&lt;javascript&gt;','&lt;java&gt;','2','JAVASCRIPT');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('12','How do you create a function in JavaScript','function = myFunction()','function:myFunction()','function myFunction()','function myFunction();','3','JAVASCRIPT');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('13','How to write an IF statement in JavaScript','if i == 5 then','if i = 5','if i = 5 then','if (i == 5) ','4','JAVASCRIPT');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('14','How do you declare a JavaScript variable','v carName;','variable carName;','var carName;','variable carName;','3','JAVASCRIPT');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('15','Where is the correct place to insert a JavaScript','The &lt;head&gt; section','Both the &lt;head&gt; section and the &lt;body&gt; section are correct','The &lt;body&gt; section','The &lt;title&gt; section','1','JAVASCRIPT');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('16','What is Python','Python is a popular programming language','Python is a client side language','Python is an object based language','None','1','PYTHON');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('17',' Which of the following is correct about Python','It supports functional and structured programming methods as well as OOP','It can be used as a scripting language or can be compiled to byte-code for building large applications','It provides very high-level dynamic data types and supports dynamic type checking','All of the above','4','PYTHON');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('18','Which of the following function convert an object to a string in python','int(x [,base])','long(x [,base] )','float(x)','str(x)','4','PYTHON');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('19','Which of the following function convert a string to a frozen set in python','','','','','','PYTHON');";
$pque .= "INSERT INTO practice (qid,question,o1,o2,o3,o4,cans,course)
VALUES ('20','What does PYTHON stands for','frozenset(s)','set(x)','chr(x)','dict(d)','1','PYTHON')";


if (mysqli_multi_query($conn, $pque)) {
    echo "<h1 align='center'>Database Entries inserted successfully</h1>";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>