<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" type="text/css" href="css\animate.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
 <?php include('nav.php'); ?>
<div class="container-fluid parallax w3-padding-top w3-center w3-margin-top">
<div class="container" style="margin:5%;"><h1 class="w3-margin-top">International Online <strong>Certification</strong> portal</h1><h2 style="color:blue;">Take your exam online, at any time, and from any location.</h2></div>
</div>

<!--Examination Info-->
<div class="container-fluid" style="background:url() no-repeat center fixed;background-size: cover;">
	<h1 class="w3-text-xxxlarge w3-center w3-text-white fadeInDownBig"><b>Certification Courses</b></h1>
	<div class="row">
		<div class="col-sm-6 w3-center" style="opacity:0.9;">
			<div class="w3-margin w3-round-large w3-hover-shadow">
				<img class="1" src="images\html5.png" style="opacity:1;max-height:200px;max-width:200px;width:100%;" data-toggle="collapse" data-target="#html" />
				<div class="w3-container">
					<h4><b>HTML 5</b></h4>
					<p  id="html" class="collapse w3-justify w3-text-black">Hypertext Markup Language (HTML) is the standard markup language for creating web pages and web applications. With Cascading Style Sheets (CSS) and JavaScript, it forms a triad of cornerstone technologies for the World Wide Web. Web browsers receive HTML documents from a web server or from local storage and render the documents into multimedia web pages. 
					<a href="exams.php" class="w3-btn w3-orange w3-round-large w3-hover-white">read more...</a></p>
				</div>
			</div>
		</div>
		<div class="col-sm-6 w3-center" style="opacity:0.9;">
			<div class="w3-round-large w3-margin w3-hover-shadow">
				<img class="1" src="images\css3.png" style="max-height:200px;max-width:200px;width:100%;" data-toggle="collapse" data-target="#css"  />
				<div class="w3-container">
					<h4><b>CSS 3</b></h4>
					<p id="css" class="collapse w3-justify">Cascading Style Sheets (CSS) is a style sheet language used for describing the presentation of a document written in a markup language like HTML. CSS is a cornerstone technology of the World Wide Web, alongside HTML and JavaScript. CSS is designed to enable the separation of presentation and content, including layout, colors, and fonts. 
					<a href="exams.php" class="w3-btn w3-orange w3-round-large w3-hover-white">read more...</a></p>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6 w3-center" style="opacity:0.9;">
			<div class="w3-round-large w3-margin w3-hover-shadow">
				<img class="1" src="images\js5.png" style="max-height:200px;max-width:200px;min-height:200px;width:100%;" data-toggle="collapse" data-target="#js"  />
				<div class="w3-container">
					<h4><b>JAVASCRIPT</b></h4>
					<p id="js" class="collapse w3-justify">JavaScript often abbreviated as JS, is a high-level, interpreted programming language. It is a language which is also characterized as dynamic, weakly typed, prototype-based and multi-paradigm. Alongside HTML and CSS, JavaScript is one of the three core technologies of the World Wide Web JavaScript enables interactive web pages and thus is an essential part of web applications. The vast majority of websites use it, and all major web browsers
					<a href="exams.php" class="w3-btn w3-orange w3-round-large w3-hover-white">read more...</a></p>
				</div>
			</div>
		</div>
		<div class="col-sm-6 w3-center" style="opacity:0.9;">
			<div class="w3-round-large w3-margin w3-hover-shadow">
				<img class="1" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/2000px-Python-logo-notext.svg.png" style="max-height:200px;max-width:200px;width:100%;" data-toggle="collapse" data-target="#bs"  />
				<div class="w3-container">
					<h4><b>Python</b></h4>
					<p id="bs" class="collapse w3-justify">Python is an interpreted high-level programming language for general-purpose programming. Created by Guido van Rossum and first released in 1991, Python has a design philosophy that emphasizes code readability, notably using significant whitespace. It provides constructs that enable clear programming on both small and large scales.
					<a href="exams.php" class="w3-btn w3-orange w3-round-large w3-hover-white">read more...</a></p>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include('footer.php'); ?>
</body>
</html>