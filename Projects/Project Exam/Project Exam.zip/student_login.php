<?php 
session_start();
$host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$e=$_SESSION['cand'];
$conn=mysqli_connect($host, $user, $pass,$dbname);

//Session User
if(!isset($_SESSION['cand']))
{
	header('Location: logout.html');
}
/*else
{
    $now = time();
	// checking the time now when home page starts
	if($now > $_SESSION['expire'])
		{
        session_destroy();
        echo "<p align='center'>Your session has expire ! <a href='login.php'>Login Here</a></p>";
		}
 */
    else
		{
		//starting this else one [else1]

?>
<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
</head>
<body>

<img class="w3-card-2 w3-margin-bottom" src="images\banner.jpg" width="100%" height="200" style="opacity:0.9;"/>



<?php
$sql="SELECT * FROM studentinfo WHERE email='$e'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
	//output data of row
	while($row=mysqli_fetch_assoc($result))
	{
		$course=$row['course'];
		GLOBAL $course;
		$_SESSION['course']=$course;
		
?>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="student_login.php"><span class="w3-left w3-xlarge">Welcome <?php echo $row['fname']." ".$row['lname']."."; ?></span></a>
    </div>
	<ul class="nav navbar-nav">
		<li><a href="student_login.php"><i class="fas fa-home w3-large"></i> Home</a></li>
	</ul>
	<ul class="nav navbar-nav navbar-right">
      <li><a href="#sdetail" class="w3-btn w3-green w3-hover-text-green w3-round w3-hover-white w3-margin-right w3-xlarge" data-toggle="collapse" >Profile</a></li>
	  <?php
		$sql2="SELECT * FROM result WHERE email='$e'";
		$result2=mysqli_query($conn,$sql2);
		$row2=mysqli_fetch_array($result2);
		if(mysqli_num_rows($result2)>0)
		{
		echo '
		<li><a href="result.php" class="w3-btn w3-teal w3-round w3-hover-white w3-hover-text-teal w3-margin-right w3-xlarge">Result</a></li>';
		}
		?>
	  <li><a href="logout.php" class="w3-btn w3-red w3-round w3-hover-white w3-hover-text-red w3-margin-right w3-xlarge">Logout</a></li>
    </ul>
</nav>


<div class="container w3-responsive w3-margin-bottom collapse" id="sdetail">
 <table class="w3-table-all text-center w3-stripped w3-card-4 table-bordered w3-hoverable w3-margin-bottom">
      <tr class="w3-sand">
        <th>Full Name</th>
        <td><?php echo $row['fname']." ".$row['mname']." ".$row['lname']."."; ?>
      </tr>
      <tr class="w3-sand">
        <th>Date of birth</th>
        <td><?php echo $row['dob']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Gender</th>
        <td><?php echo $row['gender']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Course for Examination</th>
        <td><?php echo $row['course']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Aadhar Number</th>
        <td><?php echo $row['aadhar']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Qualification</th>
        <td><?php echo $row['qualification']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Mobile Number</th>
        <td><?php echo $row['mobile']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Email ID</th>
        <td><?php echo $row['email']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Time of Registration</th>
        <td><?php echo $row['Time']; ?>
      </tr>
  </table>
</div>
<?php
}
}
 else
{
	echo "<h1>Not Found</h1>";
}


?>

<h1 class="text-center w3-text-blue">Study Material</h1>

<?php
switch($course)
{
	case "HTML" : echo "<center class='w3-margin'><a href='https://www.tutorialspoint.com/html/html_tutorial.pdf' target='_blank' class='w3-btn w3-red w3-hover-text-red w3-round w3-hover-white w3-center w3-margin-right w3-xlarge'>Download HTML PDF <i class='fas fa-file-pdf'></i></a>
	<a href='https://www.cpp.edu/~ftang/courses/CS299/notes/html.ppt' class='w3-btn w3-red w3-hover-text-red w3-round w3-hover-white w3-center w3-margin w3-xlarge'>Download HTML PPT <span><img src='images/ppt.png' width='40' height='40' /></span></a>
	</center>";
	break;
	case "CSS" : echo "<center class='w3-margin'><a href='https://www.tutorialspoint.com/css/css_tutorial.pdf' target='_blank' class='w3-btn w3-red w3-hover-text-red w3-round w3-hover-white w3-center w3-margin-right w3-xlarge'>Download CSS PDF <i class='fas fa-file-pdf'></i></a>
	<a href='https://www.webstepbook.com/supplements-2ed/slides/ppt/03-css.pptx' class='w3-btn w3-red w3-hover-text-red w3-round w3-hover-white w3-center w3-margin-right w3-xlarge'>Download CSS PPT <span><img src='images/ppt.png' width='40' height='40' /></span></a>
	</center>";
	break;
	case "JAVASCRIPT" : echo "<center class='w3-margin'><a href='https://www.tutorialspoint.com/javascript/javascript_tutorial.pdf' target='_blank' class='w3-btn w3-red w3-hover-text-red w3-round w3-hover-white w3-center w3-margin-right w3-xlarge'>Download JAVASCRIPT PDF <i class='fas fa-file-pdf'></i></a>
	<a href='https://www.webstepbook.com/supplements-2ed/slides/ppt/13-IntroJavascript.pptx' class='w3-btn w3-teal w3-hover-text-teal w3-round w3-hover-white w3-center w3-margin-right w3-xlarge'>Download JAVASCRIPT PPT <span><img src='images/ppt.png' width='40' height='40' /></span></a></center>";
	break;
	case "PYTHON" : echo "<center class='w3-margin'><a href='https://www.cs.uky.edu/~keen/115/Haltermanpythonbook.pdf' target='_blank' class='w3-btn w3-red w3-hover-text-red w3-round w3-hover-white w3-center w3-margin w3-xlarge'>Download PYTHON PDF <i class='fas fa-file-pdf'></i></a>
	<a href='https://hifweb.lbl.gov/public/slides/python.ppt' class='w3-btn w3-red w3-hover-text-red w3-round w3-hover-white w3-center w3-margin w3-xlarge'>Download PYTHON PPT <span><img src='images/ppt.png' width='40' height='40' /></span></a>
	</center>";
	break;
}
?>

<?php
		$sql="SELECT * FROM result WHERE email='$e'";
		$result=mysqli_query($conn,$sql);
		$row=mysqli_fetch_array($result);
		
		if(mysqli_num_rows($result)==0)
		{
		echo '<div class="container"><p>
  <center><div class="container col-sm-6"><button type="button" class="btn btn-success w3-xxxlarge" data-toggle="modal" data-target="#myModal" style="width:90%;">Online Exam</button></div>
  <div class="container col-sm-6"><button type="button" class="btn btn-warning w3-xxxlarge" data-toggle="modal" data-target="#practice" style="width:90%;">Practice Exam</button></div><center>
</div>';
		}
		else
		{
		echo '<div class="container"><p>
  <center>
  <div class="container col-sm-12"><button type="button" class="btn btn-warning w3-xxxlarge" data-toggle="modal" data-target="#practice" style="width:45%;">Practice Exam</button></div><center>
</div>';
		}
		?>
 <div class="container">
  <!-- Trigger the modal with a button -->
  

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><b>Rules for Examination</b></h4>
        </div>
        <div class="modal-body">
           <ol type="1"><b>	
	<li>Exam Type is Online</li>
  <li>Time Allowed For Examination is 20 minutes</li>
  <li>You can change the Answer before Submitting</li>
   <li>If you skip the Question you can go  back to that Question before time</li>
    <li>Your Result will be failed if you dont Submit your Answer before time.</li>
	<li>No Certificate will be generated if You Fail in the Exam</li>
	<li>You will have only one attempt at online exam, if you need practice then solve the practice exam first.</li>
	  <li>You need to score minimum of 70% to pass the Examination</li></b>
</ol>  
        </div>
        <div class="modal-footer">
          <a href="main.php" type="button" class="btn btn-success w3-left">Start Exam</a>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
<div class="container">
  <!-- Trigger the modal with a button -->
  

  <!-- Modal -->
  <div class="modal fade" id="practice" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><b>Rules for Examination</b></h4>
        </div>
        <div class="modal-body">
           <ol type="1"><b>	
	<li>Exam Type is Online</li>
  <li>Time Allowed For Examination is 7 minutes</li>
  <li>You can change the Answer before Submitting</li>
   <li>If you skip the Question you can go  back to that Question before time</li>
    <li>Your Result will be failed if you dont Submit your Answer before time.</li>
	  <li>You need to score minimum of 70% to pass the Examination</li></b>
</ol>  
        </div>
        <div class="modal-footer">
          <a href="pexam.php" type="button" class="btn btn-success w3-left">Start Practice Exam</a>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>




<?php include('footer.php'); ?>
</body>
</html>
<?php
 
// }
 
}
if(isset($_SESSION['pexam']))
	{
	header('Location: pexam.php');
	}
if(isset($_SESSION['exam']))
	{
	header('Location: main.php');
	}
?>