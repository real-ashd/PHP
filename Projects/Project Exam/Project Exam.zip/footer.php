<?php
echo '<footer class="main-footer" style="margin-top:5%;">
    <div class="text-center">
      <strong>Copyright &copy; 2018 <a href="#">Examination Portal</a>.</strong> All rights
    reserved.
    </div>
  </footer>';
?>