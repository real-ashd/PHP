<?php
session_start();
$e=$_SESSION['teach'];
$host="localhost";
$user="root";
$pass="";
$dbname="sregister";
//Connecting DATABASE
$conn=mysqli_connect($host, $user, $pass, $dbname);
//Session User
if(!isset($_SESSION['teach']))
{
	header('Location: logout.html');
}
/*else
{
    $now = time();
	// checking the time now when home page starts
	if($now > $_SESSION['expire'])
		{
        session_destroy();
        echo "<p align='center'>Your session has expire ! <a href='login.php'>Login Here</a></p>";
		}
 */
    else
		{
		//starting this else one [else1]
//Inserting Data in DATABASE
?>
<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
</head>
<body>

<img class="w3-card-2 w3-margin-bottom" src="images\banner.jpg" width="100%" height="200" style="opacity:0.9;"/>



<?php
$sql="SELECT * FROM teacherinfo WHERE email='$e'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
	//output data of row
	while($row=mysqli_fetch_assoc($result))
	{
?>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="lteacher.php"><span class="w3-left w3-xlarge">Welcome <?php echo $row['fname']." ".$row['lname']."."; ?></span></a>
    </div>
	<ul class="nav navbar-nav navbar-right">
      <li><a href="#sdetail" class="w3-btn w3-green w3-hover-text-green w3-round w3-hover-white w3-margin-right w3-xlarge" data-toggle="collapse" >Profile</a></li>
      <li><a href="logout.php" class="w3-btn w3-red w3-round w3-hover-white w3-hover-text-red w3-margin-right w3-xlarge">Logout</a></li>
    </ul>
</nav>
<div class="container w3-responsive w3-margin-bottom collapse" id="sdetail">
 <table class="w3-table-all text-center w3-stripped w3-card-4 table-bordered w3-hoverable w3-margin-bottom">
      <tr class="w3-sand">
        <th>Full Name</th>
        <td><?php echo $row['fname']." ".$row['mname']." ".$row['lname']."."; ?>
      </tr>
      <tr class="w3-sand">
        <th>Date of birth</th>
        <td><?php echo $row['dob']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Gender</th>
        <td><?php echo $row['gender']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Certification</th>
        <td><?php echo $row['certification']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Aadhar Number</th>
        <td><?php echo $row['aadhar']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Qualification</th>
        <td><?php echo $row['qualification']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Mobile Number</th>
        <td><?php echo $row['mobile']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Email ID</th>
        <td><?php echo $row['email']; ?>
      </tr>
      <tr class="w3-sand">
        <th>Time of Registration</th>
        <td><?php echo $row['Time']; ?>
      </tr>
  </table>
</div>

<div class="container">
 <form method="get" action="tquestion.php">
   <div class="form-group">
      <label for="sel1">Select Subject:</label>
      <select class="form-control" name="course" id="course" required>
        <option value="">---Select Subject---</option>
        <option value="HTML">HTML</option>
        <option value="CSS">CSS</option>
        <option value="JAVASCRIPT">JAVASCRIPT</option>
        <option value="PYTHON">PYTHON</option>
      </select>
	  <div>
	  <center><button type="submit" class="btn btn-warning w3-margin">Add Questions</button></center>
  </form>
</div>
</div>



<?php
}
}
 else
{
	echo "<h1>Not Found</h1>";
}
?><?php include('footer.php'); ?>
</body>
</html>


<?php
 
// }
 
}
 
?>