<?php 
session_start();

//Session User
if(!isset($_SESSION['luser']))
{
	header('Location: logout.html');
}
/*else
{
    $now = time();
	// checking the time now when home page starts
	if($now > $_SESSION['expire'])
		{
        session_destroy();
        echo "<p align='center'>Your session has expire ! <a href='login.php'>Login Here</a></p>";
		}
 */
    else
		{
		//starting this else one [else1]

?>
<!DOCTYPE html>
<html>
<head>
  <title>Examination Portal</title>
  <link rel="icon" type="image/png" href="images/tabicon2.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\W3.css">
  <link rel="stylesheet" type="text/css" href="css\icons.css">
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">  
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.css">
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.js"></script>
</head>
<body>

<img class="w3-card-2 w3-margin-bottom" src="images\banner.jpg" width="100%" height="200" style="opacity:0.9;"/>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="admin.php"><span class="w3-left w3-xlarge">Welcome <?php echo $_SESSION['luser']; ?></span></a>
    </div>
	<ul class="nav navbar-nav navbar-right">
		<li><a href="logout.php" class="w3-btn w3-xlarge w3-red w3-round-large w3-hover-white w3-margin-right w3-margin-left">Logout</a></li>
    </ul>
</nav>


<div class="container w3-light-grey w3-round-large w3-margin-top">
	<ul class="nav nav-pills nav-justified container">
		<li class="active"><a data-toggle="pill" href="#html">Candidates</a></li>
		<li class=""><a data-toggle="pill" href="#css">Teachers</a></li>
		<li class=""><a data-toggle="pill" href="#js">Results</a></li>
	</ul>
  
	<div class="tab-content w3-white w3-margin">
		<div id="html" class="tab-pane fade in active">
			<center><h3 class="w3-xxxlarge w3-padding w3-text-blue badge w3-white w3-center">Candidate Information</h3></center>
  <br>
  <table class="w3-table-all w3-stripped w3-hoverable" id="students"><center>
    <thead>
      <tr class="w3-sand">
        <th>Sr.</th>
        <th>Name</th>
        <th>Course</th>
        <th>Mobile No.</th>
        <th>Activate</th>
        <th>Deactivate</th>
        <th>Active</th>
		<th>Details</th>
      </tr>
    </thead>
    <tbody>
      <?php
	  $host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$conn=mysqli_connect($host, $user, $pass,$dbname);

$sql="SELECT id,fname,mname,lname,dob,gender,course,aadhar,qualification,mobile,email,password,Time,status FROM studentinfo";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
	//output data of row
	while($row=mysqli_fetch_assoc($result))
	{
		$id=$row['id'];
		echo "<tr>";
		echo "<form method='post'>
			<td align='center'>".$row['id'].".</td>
			<td>". $row['fname']." ".$row['lname']."</td>
			<td>".$row['course']."</td>
			<td>".$row['mobile']."</td>
			<td align='center'><a href='activate.php?a=$id'><button type='button' class='btn btn-success w3-center'>Activate</button></a></td>
			<td><a href='deactivate.php?a=$id'><button type='button' class='btn btn-danger'>Deactivate</button></a></td>
			<td>".$row['status']."</td>
			<td align='center'><a class='w3-text-blue w3-hover-text-sand' href='sinfo.php?a=$id'><u>Know More</u></a>";	
	}
}
?>
    </tbody></center>
  </table>
		</div>
		<div id="css" class="tab-pane fade">
			<center><h3 class="w3-xxxlarge w3-padding w3-margin w3-text-blue badge w3-white w3-center">Teachers Information</h3></center>
			<table class="w3-table-all w3-stripped w3-hoverable" id="teachers"><center>
    <thead>
      <tr class="w3-sand">
        <th>Sr.</th>
        <th>Name</th>
        <th>Certification</th>
        <th>Mobile No.</th>
        <th>Activate</th>
        <th>Deactivate</th>
        <th>Active</th>
		<th>Details</th>
      </tr>
    </thead>
    <tbody>
      <?php
	  $host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$conn=mysqli_connect($host, $user, $pass,$dbname);

$sql="SELECT id,fname,mname,lname,dob,gender,certification,aadhar,qualification,mobile,email,password,Time,status FROM teacherinfo";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
	//output data of row
	while($row=mysqli_fetch_assoc($result))
	{
		$id=$row['id'];
		echo "<tr>";
		echo "<form method='post'>
			<td align='center'>".$row['id'].".</td>
			<td>". $row['fname']." ".$row['lname']."</td>
			<td>".$row['certification']."</td>
			<td>".$row['mobile']."</td>
			<td align='center'><a href='tactivate.php?a=$id'><button type='button' class='btn btn-success w3-center'>Activate</button></a></td>
			<td><a href='tdeactivate.php?a=$id'><button type='button' class='btn btn-danger'>Deactivate</button></a></td>
			<td>".$row['status']."</td>
			<td align='center'><a class='w3-text-blue w3-hover-text-sand' href='tinfo.php?a=$id'><u>Know More</u></a>";
	}
}
?>
    </tbody></center>
  </table>
		</div>
		<div id="js" class="tab-pane fade">
			<center><h3 class="w3-xxxlarge w3-padding w3-margin w3-text-blue badge w3-white w3-center">Results </h3></center>
			<table class="w3-table-all w3-stripped w3-hoverable" id="result"><center>
    <thead>
      <tr class="w3-sand">
        <th>Sr.</th>
        <th>Name</th>
        <th>Course</th>
        <th>Email</th>
        <th>Right Ans</th>
        <th>Wrong Ans</th>
        <th>Percent</th>
		<th>Result</th>
      </tr>
    </thead>
    <tbody>
      <?php
	  $host="localhost";
$user="root";
$pass="";
//Connect to database Ashu
$dbname="sregister";
$conn=mysqli_connect($host, $user, $pass,$dbname);

$sql="SELECT * FROM result";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
	$i=1;
	while($row=mysqli_fetch_assoc($result))
	{
		echo "<tr>";
		echo "<form method='post'>
			<td align='center'>".$i.".</td>
			<td>". $row['fname']." ".$row['lname']."</td>
			<td>".$row['course']."</td>
			<td>".$row['email']."</td>
			<td>".$row['rights']."</td>
			<td>".$row['wrong']."</td>
			<td>".$row['percent']." %</td>
			<td>";
			if($row['percent']>='70')
			{echo "<b class='w3-text-green'>Pass</b>";}
			else {echo "<b class='w3-text-red'>Fail</b>";}
			echo "</td>";
	}
}
?>
    </tbody></center>
  </table>
		</div>
  </div>
</div>

<div class="container w3-responsive">
  
  
</div>
<script>
$(document).ready(function(){
	$('#students').DataTable();
});
$(document).ready(function(){
	$('#teachers').DataTable();
});
$(document).ready(function(){
	$('#result').DataTable();
});
</script> 
<?php include('footer.php'); ?>
</body>
</html>
<?php
 
// }
 
}
 
?>