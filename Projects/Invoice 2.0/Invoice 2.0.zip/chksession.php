<?php
if(isset($_SESSION['emp']))
{echo "login";}
else{header('Location: emplogout.php');}
?>