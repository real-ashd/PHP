<?php
include('chksession.php');
echo "Dashboard";
echo "<br>
	<a href='emplogout.php'>Dashboard</a>";
?>