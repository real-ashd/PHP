<?php
echo '<footer class="container-fluid w3-text-white w3-center" style="background: linear-gradient(to left, #0066ff 0%, #99ccff 100%);" >
	<div style="  padding: 25px 30px 30px 30px;">
		<p><i class="far fa-copyright"></i> Copyright 2018 <a href="#" style="text-decoration: none;" class="w3-hover-text-light-blue w3-xlarge animated infinite tada"> Invoice</a>. All Rights Reserved.</p>
		<p>Developed  by : <b class="w3-text-white"><a href="http://microspectra.in/" style="text-decoration: none;" class="w3-hover-text-light-blue animated infinite tada" >MICROSPECTRA Software Technology, Shegaon</a></b></p>
	</div>
</footer>';
?>