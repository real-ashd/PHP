<?php
session_start();
//Employee Login
include('chklogin.php');
if(isset($_SESSION['emp']))
{header('Location: empdashboard.php');}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Invoice</title>
  <link rel="icon" type="image/png" href="http://tableshare.jp/boardgamewiki/image/paraedit.png" style="background-color:white;"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css\invoice.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.css">
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.js"></script>
</head>
<body class="w3-light-grey">

<h1 class="w3-text-dark-grey w3-center animated infinite fadeIn" style="margin-top:8%;">Invoice</h1>
<div class="container ">
<!--<div class="w3-card-4" style="width:100%;height:500px">-->





<div class="w3-card-4 w3-white w3-round animated swing" style="padding:25px;margin:auto;margin-top:2%;max-width:480px;">
	<div class="form-group">
		<label class="w3-xlarge w3-center" style="color:blue;">Employee Login</label>
		</div>
		<form method="post">
	<div class="form-group">
		<label class="form-label " for="eid">Employee ID</label>
		<input id="eid" name="eid" class="form-input input1 w3-input" type="text" required />
	</div>
	<?php echo @$a;?>
	<div class="form-group">
		<label class="form-label " for="password">Password</label>
		<input id="password" name="pass" class="form-input input1 w3-input" type="password" required />
	</div>
	<center>
		<input type="Submit" value="Log In" name="login" style="width:120px;margin:auto;" class="w3-btn w3-btn-block w3-green w3-round w3-large w3-hover-pale-blue w3-hover-text-green w3-ripple w3-margin-top"></input>
	</center>
	</div>
	</form>
</div>
<div class="content">
  <div class="column">
    <div class="container animation-3">
      <div class="shape shape1"></div>
      <div class="shape shape2"></div>
      <div class="shape shape3"></div>
      <div class="shape shape4"></div>
    </div>
  </div>
</div>
<!--</div>-->
</div>
<script>
$('input').focus(function(){
  $(this).parents('.form-group').addClass('focused');
});

$('input').blur(function(){
  var inputValue = $(this).val();
  if ( inputValue == "" ) {
    $(this).removeClass('filled');
    $(this).parents('.form-group').removeClass('focused');  
  } else {
    $(this).addClass('filled');
  }
})
</script>
</body>
</html>