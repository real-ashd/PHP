<?php
//Employee Login
if(isset($_POST['login']))
{
	$u = $_POST['eid'];
	$p = $_POST['pass'];
	include("database/dbconn.php");
	$sql="SELECT * FROM employeeinfo";
	$result=mysqli_query($conn,$sql);
	while($row=mysqli_fetch_array($result))
	{
		if($u == $row['employeeid'] && $p == $row['password'])
		{
			if($row['active']=='1')
			{
				$_SESSION['emp']=$row['employeeid'];
				header('Location: empdashboard.php');
			}
			else
			{
				$a="<i class='w3-text-red'>*You are not Authorised!!! Contact Admin to Grant you access</i>";
			}
		}
		else
		{
			echo "<script>alert('Wrong Id or Password!!!');</script>";
		}
	}
}
?>