<!DOCTYPE html>
<html lang="en">
<head>
  <title>Employee Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" type="text/css" href="css\animate.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous"> 
</head>
<body>
<div class="container-fluid w3-text-white w3-center" style="font-size:70px;font-family:Times New Roman;  background: linear-gradient(to right, #0066ff 0%, #99ccff 100%); "><span class=" animated infinite w3-animate-opacity">Invoice</span></div>
<div class="container col-sm-6" style="margin-top:5%; margin-bottom:5%">
  <div class="w3-card-4 w3-margin-top">
    <header class=" display-4 font-weight-bold  w3-indigo w3-container w3-card-4">
     <h1>Employee Login</h1>
    </header>	
    <div class="w3-panel">
    <div class="w3-row">
    <form>	
	<div class="form-group">
		<label class="form-label " for="ename"> <i class="fas fa-user"></i> Employee ID</label>
		<input id="ename" name=" " class="form-input input1 w3-input" style="color: #1981e8; font-size:20px; font-weight:20px" type="text" autocomplete required pattern=[A-Za-z]{3,30} maxlength="30" title="Enter the Employee name..." />
	</div>
	
	<div class="form-group">
		<label class="form-label" for="password"><i class="fas fa-lock "></i> Password</label>
		<input id="password" name=" " class="form-input input1 w3-input" type="password"     style="color: #1981e8; font-size:20px;" autocomplete required title="Enter the Password..." />     
		<br>
	</div>  	
   </div>
  </div>		
  <div class="container-fluid w3-indigo " style="position:relative">
  <button type="Submit" class="w3-btn w3-xlarge w3-right w3-hover-green w3-hover-text-indigo w3-padding" style="position:absolute;top:-28px;right:16px;padding:10px; background: linear-gradient(to bottom right, #0066ff 0%, #99ccff 100%);">Login</button>
  </br></br>
</form>
</div>
</div>
 </div>
<?php include('footer.php'); ?>
<script>
$('input').focus(function(){
  $(this).parents('.form-group').addClass('focused');
});

$('input').blur(function(){
  var inputValue = $(this).val();
  if ( inputValue == "" ) {
    $(this).removeClass('filled');
    $(this).parents('.form-group').removeClass('focused');  
  } else {
    $(this).addClass('filled');
  }
})
</script>

</form>
</body>
</html> 