<?php
include('dbconn.php');

$sql="DELETE FROM clientinfo WHERE invoice_no='MIC100000'";
mysqli_query($conn, $sql);
$sql="DELETE FROM descript WHERE invoice_no='MIC100000'";
mysqli_query($conn, $sql);
$sql="DELETE FROM invoices WHERE invoice_no='MIC100000'";
mysqli_query($conn, $sql);
$sql="DELETE FROM service_provider WHERE state='USA'";
mysqli_query($conn, $sql);
$sql="DELETE FROM employeeinfo WHERE fname='sample'";
mysqli_query($conn, $sql);

echo "<h1 align='center'>Invoice Data Deleted.</h1>";
include('icon.php');
?>