<?php
$host="sql200.epizy.com";
$user="epiz_28619284";
$pass="UrPOoBbJG4Z30I";
$dbname = "epiz_28619284_invoice2";

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}
  echo "Connected successfully";
?>