<?php
include('dbtables.php');


echo "<h1 align='center'>Invoice Database Created</h1>";


echo "<h1 align='center'><a href='dbentries.php' target='_blank'>Insert Sample Data Entries</a></h1>";

echo "<h1 align='center'><a href='dlentries.php'>Delete Sample Data Entries From the Database</a></h1>";
include('icon.php');
?>