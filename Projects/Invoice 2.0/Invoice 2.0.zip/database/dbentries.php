<?php
include_once('dbtables.php');


//Insert Into Invoice
$sql3="INSERT INTO clientinfo(clientid,invoice_no,company,attendent,email,address,city,pin,state,country,generation_date,due_date,status,payment_method)
VALUES('','MIC100000','Sample','SAM','sample@gmail.com','samples2','newyork','444444','usa','america','2017/01/01','2017/01/02','UNPAID','cash')";
mysqli_query($conn,$sql3);


//Insert Into Service Provider
$sql3="INSERT INTO service_provider(companyid,company_name,initials,email,address,city,pin,state,country)
VALUES('','Microspectra','MIC','sample@gmail.com','samples2','New York','444444','USA','North America')";
mysqli_query($conn,$sql3);


//Insert Into Description
$sql6="INSERT INTO descript(invoice_no,attendent,description,qty,charges,credits)
VALUES('MIC100000','SAM','sample1','1','11','0')";
mysqli_query($conn,$sql6);


//Insert Into Description
$sql7="INSERT INTO descript(invoice_no,attendent,description,qty,charges,credits)
VALUES('MIC100000','SAM','sample2','2','112','0')";
mysqli_query($conn,$sql7);


//Insert Into Invoices
$sql8="INSERT INTO invoices(invoice_no,email)
VALUES('MIC100000','sample@123.com')";
mysqli_query($conn,$sql8);


//Insert Into EmployeeInfo
$sql8="INSERT INTO employeeinfo(id,employeeid,fname,lname,company,email,mobile,password,active)
VALUES('','SAM101','sample','sample1','SAMPLES','sample@gmail','9999999999','123','1')";
mysqli_query($conn,$sql8);


echo "<h1 align='center'>Invoice Data Inserted.</h1>";

echo "<h1 align='center'><a href='dlentries.php'>Delete Sample Data Entries</a></h1>";
include('icon.php');
?>