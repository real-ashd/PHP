<?php
$host="sql200.epizy.com";
$user="epiz_28619284";
$pass="UrPOoBbJG4Z30I";

//Connecting DATABASE
$conn=mysqli_connect($host, $user, $pass);
if(!$conn)
  {
   echo "Connection Failed!!!!<br/>";
  }
else
  {
   echo mysqli_error($conn);
  }
  
//Create DATABASE
$sql="CREATE DATABASE invoice2";
mysqli_query($conn,$sql);
?>