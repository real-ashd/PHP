<?php 
echo '<!DOCTYPE html>
<html>
<head>
  <title>Invoice</title>
  <link rel="icon" type="image/png" href="http://tableshare.jp/boardgamewiki/image/paraedit.png" style="background-color:white;"/>
</head>';
?>