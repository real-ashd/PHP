<?php
include('dbconn.php');


//Create Table ClientInfo
$sql="CREATE TABLE clientinfo(
clientid BIGINT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
invoice_no VARCHAR(255) NOT NULL,
company VARCHAR(255) NOT NULL,
attendent VARCHAR(255) NOT NULL,
email VARCHAR(255) NOT NULL,
address VARCHAR(100) NOT NULL,
city VARCHAR(255) NOT NULL,
pin INT(6) NOT NULL,
state VARCHAR(255) NOT NULL,
country VARCHAR(255) NOT NULL,
generation_date DATE,
due_date DATE,
status VARCHAR(255) NOT NULL,
payment_method VARCHAR(30),
Time TIMESTAMP
) AUTO_INCREMENT = 100001";
mysqli_query($conn,$sql);


//Create Table Service Provider
$sql11="CREATE TABLE service_provider(
companyid INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
company_name VARCHAR(255) NOT NULL,
initials VARCHAR(255) NOT NULL,
email VARCHAR(255) NOT NULL,
address VARCHAR(100) NOT NULL,
city VARCHAR(255) NOT NULL,
pin INT(6) NOT NULL,
state VARCHAR(255) NOT NULL,
country VARCHAR(255) NOT NULL
)";
mysqli_query($conn,$sql11);


//Create Table Descript
$sql1="CREATE TABLE descript(
invoice_no VARCHAR(255) NOT NULL,
attendent VARCHAR(50) NOT NULL,
description VARCHAR(100) NOT NULL,
qty INT(6),
charges INT(6),
credits INT(6)
)";
mysqli_query($conn,$sql1);


//Create Table Invoices
$sql2="CREATE TABLE invoices(
invoice_no VARCHAR(255) NOT NULL,
email VARCHAR(100) NOT NULL,
sendTime TIMESTAMP
)";
mysqli_query($conn,$sql2);

//Create Table Employee Info
$sql3="CREATE TABLE employeeinfo(
id BIGINT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
employeeid VARCHAR(255) NOT NULL,
fname VARCHAR(255) NOT NULL,
lname VARCHAR(255) NOT NULL,
company VARCHAR(255) NOT NULL,
mobile VARCHAR(255) NOT NULL,
email VARCHAR(255) NOT NULL,
password VARCHAR(255) NOT NULL,
active VARCHAR(255) NOT NULL,
image LONGBLOB,
reg_at TIMESTAMP
) AUTO_INCREMENT = 101";
mysqli_query($conn,$sql3);
?>