<!DOCTYPE html>
<html lang="en">
<head>
  <title>Employee Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css\css1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">  
</head>
<body >
<div class="container-fluid w3-blue w3-center" style="font-size:70px;font-family:Times New Roman">Invoice</div>

<div class="container col-sm-8" style="margin-top:5%; margin-bottom:5%">
  <div class="w3-card-4 w3-margin-top">
    <header class=" display-4 font-weight-bold  w3-indigo w3-container w3-card-4 ">
     <h1>Employee Registration</h1>
    </header>	
    <div class="w3-panel">
    <div class="w3-row">
    <form>
	<div class="form-group">
		<label class="form-label " for="company_name"><i class="fas fa-users"></i>  Company Name</label>
		<input id="company_name" name=" " class="form-input input1 w3-input" type="text" style="color: #1981e8; font-size:20px;"  autocomplete required pattern={3,60} maxlength="60"  title="Enter the Company name..." />
	</div>
	<div class="form-group">
		<label class="form-label " for="name"> <i class="fas fa-user"></i> First Name</label>
		<input id="name" name=" " class="form-input input1 w3-input" style="color: #1981e8; font-size:20px; font-weight:20px" type="text" autocomplete required pattern=[A-Za-z]{3,30} maxlength="30" title="Enter the First name..." />
	</div>
	<div class="form-group">
		<label class="form-label " for="lname"> <i class="fas fa-user"></i> Last Name</label>
		<input id="lname" name=" " class="form-input input1 w3-input" type="text"  style="color: #1981e8; font-size:20px;" autocomplete required pattern=[A-Za-z]{3,30} maxlength="30" title="Enter the Last name..." />
	</div>
	<div class="form-group">
		<label class="form-label" for="mob_no"><i class="fas fa-mobile-alt"></i> Mobile No.</label>
		<input id="mob_no" name=" " class="form-input input1 w3-input" type="text"  style="color: #1981e8; font-size:20px;" autocomplete pattern=[0-9]{10} maxlength="10" required title="Enter the Mobile No. . . . . only Digits  " />
	</div>
	<div class="form-group">
		<label class="form-label " for="email"><i class="fas fa-envelope"></i>  Email</label>
		<input id="email" name=" " class="form-input input1 w3-input" type="email"          style="color: #1981e8; font-size:20px;" autocomplete required title="Enter the E-mail Address..."  />
	</div>
	<div class="form-group">
		<label class="form-label" for="password"><i class="fas fa-lock "></i> Password</label>
		<input id="password" name=" " class="form-input input1 w3-input" type="password"     style="color: #1981e8; font-size:20px;" autocomplete required title="Enter the Password..." />
	</div>
     <div class="form-group">
		<label class="form-label " for="confirm_password"><i class="fas fa-lock "></i> Confirm Password</label>
		<input id="confirm_password" name=" " class="form-input input1 w3-input" type="password" style="color: #1981e8; font-size:20px;" autocomplete required title="Enter the Confirm Password..."/>
		<br>
	</div>  	
   </div>
  </div>		
  <footer class="container-fluid w3-indigo " style="position:relative">
  <button type="Submit" class="w3-btn w3-xlarge  w3-blue w3-right w3-hover-pale-blue w3-hover-text-blue" style="position:absolute;top:-28px;right:16px;">Register</button>
  </br></br>
</footer>
</form>
</div>
 </div>
 
 <div class="container-fluid w3-blue w3-center" >
 <footer style="  padding: 25px 30px 30px 30px;">
	  <p><i class="far fa-copyright"></i> Copyright 2018 <a href="#" class="w3-hover-text-pink w3-text-lime w3-xlarge"> Invoice</a>. All Rights Reserved.</p>
	  <p>Developed  by : <a href="http://microspectra.in/" class="w3-hover-text-light-blue w3-text-aqua" >MICROSPECTRA Software Technology, Shegaon</a></p>
    </footer>
</div>

<script>
$('input').focus(function(){
  $(this).parents('.form-group').addClass('focused');
});

$('input').blur(function(){
  var inputValue = $(this).val();
  if ( inputValue == "" ) {
    $(this).removeClass('filled');
    $(this).parents('.form-group').removeClass('focused');  
  } else {
    $(this).addClass('filled');
  }
})
</script>
<!--for confirm password-->
<script >
var password = document.getElementById("password")
  , confirm_password = document.getElementById("confirm_password");

function validatePassword(){
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
  } else {
    confirm_password.setCustomValidity('');
  }
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;
</script>


</form>
</body>
</html> 